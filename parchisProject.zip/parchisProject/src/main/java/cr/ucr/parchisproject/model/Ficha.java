/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ucr.parchisproject.model;

import java.awt.Image;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author Xpc
 */
public class Ficha {
    
    private String color;
    private int posicionActual; //Solo contemplaba el camino principal 1-68
    private int x;
    private int y;
    boolean enCasa;
    boolean enMeta;
    private boolean enCaminoFinal;
    private int posicionFinal;    // 0–7 (7 = meta)
    private int entradaFinal;     // casilla donde entra al camino final
    private Image imagen;

    public Ficha(String color, int xInicial, int yInicial) {
        this.color = color;
        this.posicionActual = 0;
        this.x = xInicial;
        this.y = yInicial;
        this.enCasa = true;
        this.enMeta = false;
        this.enCaminoFinal = false;
        this.posicionFinal = -1;
        asignarEntradaFinal(color);
        cargarImagenFicha(color);
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPosicionActual() {
        return posicionActual;
    }

    public void setPosicionActual(int posicionActual) {
        this.posicionActual = posicionActual;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean isEnCasa() {
        return enCasa;
    }

    public void setEnCasa(boolean enCasa) {
        this.enCasa = enCasa;
    }

    public boolean isEnMeta() {
        return enMeta;
    }

    public void setEnMeta(boolean enMeta) {
        this.enMeta = enMeta;
    }  

    public Image getImagen() {
        return imagen;
    }
    
    
    
    //Carga imagen de ficha segun color
    private void cargarImagenFicha(String color) {
        try {
            switch (color.toLowerCase()) {
                case "rojo":
                    imagen = ImageIO.read(new File("resources/img/FichaFuego.png"));
                    break;
                case "azul":
                    imagen = ImageIO.read(new File("resources/img/FichaAgua.png"));
                    break;
                case "amarillo":
                    imagen = ImageIO.read(new File("resources/img/FichaElectrico.png"));
                    break;
                case "verde":
                    imagen = ImageIO.read(new File("resources/img/FichaPlanta.png"));
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error cargando imagen de ficha " + color);
        }
    }
    
    //Asigna entrada final
    private void asignarEntradaFinal(String color) {
        switch (color.toLowerCase()) {
            case "rojo":
                entradaFinal = 64;
                break;
            case "azul":
                entradaFinal = 47;
                break;
            case "amarillo":
                entradaFinal = 30;
                break;
            case "verde":
                entradaFinal = 13;
                break;
        }
    }
    
    //Movimiento ficha
    //Los return vacios significan salir inmediatamente de este método y no ejecutar nada más (Es como un break chafa), era esto o todo a puro if y else
    public void mover(int pasos) {
        ////Si está en casa o en meta > no mueve > salga del método
        if (enCasa || enMeta)
            return;
        
        //Si ya está en camino final, no debe seguir ejecutando la lógica del camino principal.
        if (enCaminoFinal) {
            moverEnCaminoFinal(pasos);
            return;
        }
        
        // Movimiento normal
        posicionActual += pasos;
        
        //Verifica si pasa por la entrada del camino final
        if (posicionActual == entradaFinal) {
            enCaminoFinal = true;
            posicionFinal = 0;
            return;
        }
        //No debería llegar aquí, es como un try-catch, ya que todas las fichas terminan antes
        if (posicionActual > 68) {
            posicionActual = 68;
        }
    }
    
    private void moverEnCaminoFinal(int pasos) {
        if (enMeta) return;
        int nuevaPosFinal = posicionFinal + pasos;
        // Debe caer EXACTO en 7 para ganar
        if (nuevaPosFinal == 7) {
            posicionFinal = 7;
            enMeta = true;
            return;
        }
        // Si se pasa, no se mueve
        if (nuevaPosFinal > 7) {
            return;
        }
        // Avanza normal
        posicionFinal = nuevaPosFinal;
    }
    
    //Dado igual 5 para sacarlo de la casa
    public void salirDeCasa(int posicionSalida) {
        if (enCasa) {
            posicionActual = posicionSalida;
            enCasa = false;
        }
    }
    
    //Envia la ficha a casa(por colison o error)
    public void volverACasa() {
        posicionActual = 0;
        enCasa = true;
        enMeta = false;
        enCaminoFinal = false;
        posicionFinal = -1;
    }
    
    public void actualizarCoordenadas(int nuevaX, int nuevaY) {
        this.x = nuevaX;
        this.y = nuevaY;
    }
    
    
}
